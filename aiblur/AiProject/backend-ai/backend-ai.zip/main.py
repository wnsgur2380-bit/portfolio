# (신규) .env 파일을 읽기 위해 load_dotenv를 임포트
from dotenv import load_dotenv

# (신규) 다른 모든 임포트보다 먼저 .env 파일을 로드합니다.
load_dotenv()

from fastapi import FastAPI, File, UploadFile, Depends, Form, HTTPException, Path, Body
from fastapi.middleware.cors import CORSMiddleware # CORS 설정
from fastapi.staticfiles import StaticFiles # 파일 서버 임포트
# 🚨 신규: 파일 다운로드를 위해 FileResponse 임포트
from fastapi.responses import FileResponse 
from sqlmodel import SQLModel, Session, select, func
from sqlalchemy import or_ # 검색 기능에 필요
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import uuid # 파일의 고유한 이름을 만들기
import asyncio # 비동기 처리를 위함
from database import async_engine, create_db_and_tables, get_async_session
import models
import security
import shutil # 파일 저장을 위한 shutil 라이브러리 추가
import os 
import cv2
import numpy as np # [팀원 기능] 행렬 연산을 위해 추가
import requests # [팀원 기능] 모델 파일 다운로드를 위해 추가
import bz2 # [팀원 기능] 압축 해제를 위한 라이브러리
from ultralytics import YOLO # YOLOv8 사용

# --- 상태 상수 정의 (한글) ---
STATUS_PENDING = "분석 대기중"
STATUS_IN_PROGRESS = "분석 진행중" 
STATUS_COMPLETED = "분석 완료"
ADMIN_PASSWORD = "1234" 


# --- Pydantic 모델 (API 응답용) ---

# React로 보낼 게시글 목록 데이터 형식 (비밀번호, 내용, 경로 제외)
class PostResponse(BaseModel):
    id: int
    title: str
    author: str
    status: str
    created_at: datetime
    original_video_filename: str 
    
    class Config:
        from_attributes = True # SQLModel 객체를 Pydantic 모델로 변환

# 상세 보기 응답 모델
class PostDetailResponse(PostResponse):
    content: Optional[str]
    email: str
    analyzed_video_path: Optional[str] # 분석 완료 여부 확인용
    
    class Config:
        from_attributes = True

# 페이지네이션 응답 모델
class PaginatedPostResponse(BaseModel):
    total_posts: int
    total_pages: int
    posts: List[PostResponse]

# 🚨 신규: 비밀번호 확인 요청 모델
class PasswordCheck(BaseModel):
    password: str
# ------------------------------------

# --- uploads 폴더 설정 ---
UPLOAD_DIRECTORY = "uploads"
if not os.path.exists(UPLOAD_DIRECTORY):
    os.makedirs(UPLOAD_DIRECTORY)

# [팀원 기능] DLL 충돌 방지 및 경로 설정 (Windows 환경 호환성)
if hasattr(os, 'add_dll_directory'):
    try:
        os.add_dll_directory(os.getcwd())
    except Exception:
        pass
os.environ['PATH'] = os.getcwd() + ';' + os.environ['PATH']
    
# FastAPI 먼저 선언
app = FastAPI()

# (중요) React(3000번)에서 오는 요청을 허용
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"], # React 서버 주소
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 파일 서버 마운트 (분석된 영상 등을 클라이언트에 제공)
# 팀원 코드는 /static을 썼지만, 사용자님 코드는 /uploads를 유지합니다.
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIRECTORY), name="uploads")


# AI 모델을 담을 전역 변수 선언
model = None 

# FastAPI 시작 이벤트
@app.on_event("startup")
async def on_startup():
    await create_db_and_tables()
    
    # 객체 탐지용 YOLO 모델 로드 (분석 요청 시 사용)
    global model 
    try:
        model = YOLO('yolov8n.pt')
        print("YOLOv8 (객체 탐지) 모델 로드 성공!")
        print(model.names) 
    except Exception as e:
        print(f"YOLOv8 모델 로드 실패: {e}")
        model = None

@app.get("/")
def read_root():
    return {"Hello": "Backend"}

# -----------------------------------------------
# --- [팀원 기능 통합] YOLOv8 Face 분석 함수 ---
# -----------------------------------------------

def check_and_download_files():
    """[팀원 기능] YOLOv8 Face 모델과 필수 DLL을 다운로드합니다."""
    base_path = os.getcwd()
    
    # 1. YOLOv8 Face 모델 (최신 얼굴 인식 전용 모델)
    yolo_model_name = "yolov8n-face.pt"
    yolo_path = os.path.join(base_path, yolo_model_name)

    # 2. 코덱 DLL (영상 저장용)
    target_dll = "openh264-1.8.0-win64.dll"
    dll_path = os.path.join(base_path, target_dll)

    # YOLO 모델 다운로드
    if not os.path.exists(yolo_path):
        print(f"최신 AI 모델(YOLOv8-Face) 다운로드 중... ({yolo_model_name})")
        try:
            # 얼굴 인식 특화 YOLO 모델
            url = "https://github.com/akanametov/yolo-face/releases/download/v0.0.0/yolov8n-face.pt"
            r = requests.get(url, stream=True)
            with open(yolo_path, 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
            print(" -> AI 모델 설치 완료")
        except Exception as e:
            print(f" -> AI 모델 다운로드 실패: {e}")

    # 코덱 DLL 다운로드 (v1.8.0) - 없는 경우에만
    if not os.path.exists(dll_path):
        print(f"코덱 DLL 다운로드 중... ({target_dll})")
        try:
            url = "http://ciscobinary.openh264.org/openh264-1.8.0-win64.dll.bz2"
            r = requests.get(url, stream=True)
            decompressed_data = bz2.decompress(r.content)
            with open(dll_path, 'wb') as f: f.write(decompressed_data)
            print(" -> DLL 설치 완료")
        except Exception as e:
            print(f" -> DLL 실패: {e}")

    return yolo_path

def process_video_for_privacy(video_path: str) -> dict:
    """[팀원 기능] YOLOv8 Face를 사용하여 얼굴을 초정밀 탐지하고 블러 처리합니다."""
    
    # 모델 파일 체크 및 다운로드
    yolo_path = check_and_download_files()
    print(f"'{video_path}' YOLOv8 Face(얼굴 전용) 분석 시작...")

    try:
        # 얼굴 인식 전용 YOLO 모델 로드
        face_model = YOLO(yolo_path)
    except Exception as e:
        return {"error": f"YOLO 모델 로드 실패: {str(e)}"}
    
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return {"error": "비디오 파일을 열 수 없습니다."}

    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    if fps == 0.0: fps = 30.0

    # [수정] 사용자님의 파일 저장 규칙 유지 (원본명_blurred.mp4)
    original_base_name = os.path.basename(video_path)
    base, ext = os.path.splitext(original_base_name)
    
    # UUID 제거하고 원본 파일명 추출
    parts = base.split('_', 1)
    if len(parts) > 1 and len(parts[0]) == 36:
        clean_base = parts[1]
    else:
        clean_base = base
        
    blurred_filename = f"{clean_base}_blurred{ext}"
    # [중요] 사용자님 코드는 UPLOAD_DIRECTORY를 사용하므로 여기 저장
    blurred_filepath = os.path.join(UPLOAD_DIRECTORY, blurred_filename)

    # 코덱 설정 (avc1 -> mp4v 폴백)
    fourcc = cv2.VideoWriter_fourcc(*'avc1')
    out = cv2.VideoWriter(blurred_filepath, fourcc, fps, (frame_width, frame_height))

    if not out.isOpened():
        print("avc1 코덱 실패, mp4v로 전환합니다.")
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(blurred_filepath, fourcc, fps, (frame_width, frame_height))

    face_detected_count = 0

    try:
        while cap.isOpened():
            success, frame = cap.read()
            if not success:
                break

            # [YOLO 추론] conf=0.25: 확신도 25% 이상인 것만 잡음
            results = face_model(frame, conf=0.25, verbose=False)

            # 탐지된 결과 루프
            for result in results:
                boxes = result.boxes
                for box in boxes:
                    face_detected_count += 1
                    
                    # 좌표 추출
                    x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                    startX, startY, endX, endY = int(x1), int(y1), int(x2), int(y2)

                    face_w = endX - startX
                    face_h = endY - startY

                    # [패딩] 타원형에 맞게 자연스럽게 확장
                    pad_top = int(face_h * 0.15)
                    pad_bottom = int(face_h * 0.10)
                    pad_side = int(face_w * 0.05)

                    startX = max(0, startX - pad_side)
                    startY = max(0, startY - pad_top)
                    endX = min(frame_width, endX + pad_side)
                    endY = min(frame_height, endY + pad_bottom)

                    face_roi = frame[startY:endY, startX:endX]
                    
                    if face_roi.shape[0] > 0 and face_roi.shape[1] > 0:
                        # 타원형 블러 적용
                        k_w = int((endX - startX) / 1.5)
                        k_h = int((endY - startY) / 1.5)
                        if k_w % 2 == 0: k_w += 1
                        if k_h % 2 == 0: k_h += 1
                        k_w = max(k_w, 1)
                        k_h = max(k_h, 1)
                        
                        try:
                            blurred_face = cv2.GaussianBlur(face_roi, (k_w, k_h), 0)
                            
                            # 타원 마스크 생성
                            mask = np.zeros_like(face_roi)
                            rows, cols, _ = mask.shape
                            center = (cols // 2, rows // 2)
                            axes = (cols // 2, rows // 2)
                            cv2.ellipse(mask, center, axes, 0, 0, 360, (255, 255, 255), -1)
                            
                            # 합성
                            frame[startY:endY, startX:endX] = np.where(mask > 0, blurred_face, face_roi)
                        except: pass
            
            out.write(frame)

    except Exception as e:
        print(f"영상 처리 중 오류: {e}")
    finally:
        cap.release()
        out.release()
        
    print(f"'{blurred_filepath}' YOLO 분석 완료. (총 {face_detected_count} 프레임에서 얼굴 탐지)")

    return {
        "detection_summary": {"faces_blurred": face_detected_count},
        # [중요] 사용자님 App.js는 /uploads 경로를 기대하므로 맞춤
        "analyzed_video_url": f"/uploads/{blurred_filename}",
        "analyzed_video_path": blurred_filepath
    }

def analyze_video_with_yolo(video_path: str) -> dict:
    """(기존 기능) 일반 객체 탐지용 YOLOv8"""
    if model is None:
        return {"error": "YOLOv8 모델이 로드되지 않았습니다."}
    
    print(f"'{video_path}' YOLOv8 객체 탐지 시작...")
    detection_counts = {}
    cap = cv2.VideoCapture(video_path)
    
    while cap.isOpened():
        success, frame = cap.read() 
        if not success:
            break 
            
        results = model(frame)
        boxes = results[0].boxes

        for box in boxes:
            cls_id = int(box.cls[0])
            cls_name = model.names[cls_id]
            if float(box.conf[0]) > 0.5:
                detection_counts[cls_name] = detection_counts.get(cls_name, 0) + 1

    cap.release()
    print(f"'{video_path}' 객체 탐지 완료.")
    return {"detection_summary": detection_counts}

    
# -----------------------------------------------
# --- API 엔드포인트 ---
# -----------------------------------------------

# [다운로드 API]
@app.get("/api/download/{file_name}")
async def download_file(file_name: str = Path(..., description="다운로드할 파일의 이름")):
    base_name = os.path.basename(file_name)
    file_path = os.path.join(UPLOAD_DIRECTORY, base_name)

    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="파일을 찾을 수 없습니다.")

    return FileResponse(
        file_path, 
        filename=base_name, 
        media_type='application/octet-stream'
    )

# [게시글 목록 API]
@app.get("/api/posts", response_model=PaginatedPostResponse)
async def get_posts(
    session: AsyncSession = Depends(get_async_session),
    search: str = "", 
    page: int = 1, 
    status_filter: Optional[str] = None 
):
    limit: int = 10 
    statement = select(models.AnalysisRequest)
    
    if status_filter == STATUS_PENDING or status_filter == STATUS_IN_PROGRESS: 
        statement = statement.where(
            or_(
                models.AnalysisRequest.status == STATUS_PENDING,
                models.AnalysisRequest.status == STATUS_IN_PROGRESS
            )
        )
    elif status_filter == STATUS_COMPLETED:
        statement = statement.where(models.AnalysisRequest.status == STATUS_COMPLETED)
    
    if search:
        search_term = f"%{search}%"
        statement = statement.where(
            or_(
                models.AnalysisRequest.author.like(search_term),
                models.AnalysisRequest.email.like(search_term)
            )
        )

    count_statement = select(func.count()).select_from(statement.subquery())
    total_posts_result = await session.execute(count_statement)
    total_posts = total_posts_result.scalar_one_or_none() or 0
    
    offset = (page - 1) * limit
    statement = statement.order_by(models.AnalysisRequest.id.desc()).offset(offset).limit(limit)
    
    results = await session.execute(statement)
    posts = results.scalars().all()
    
    total_pages = (total_posts + limit - 1) // limit if limit > 0 else 0
    if total_pages == 0 and total_posts > 0:
        total_pages = 1

    return {
        "total_posts": total_posts,
        "total_pages": total_pages,
        "posts": posts 
    }

# [게시글 상세 보기 API]
@app.get("/api/posts/{post_id}", response_model=PostDetailResponse)
async def get_post_detail(
    post_id: int = Path(..., description="조회할 게시글의 ID"), 
    session: AsyncSession = Depends(get_async_session)
):
    statement = select(models.AnalysisRequest).where(
        models.AnalysisRequest.id == post_id
    )
    result = await session.execute(statement)
    db_post = result.scalars().one_or_none()

    if not db_post:
        raise HTTPException(status_code=404, detail=f"게시글 ID {post_id}를 찾을 수 없습니다.")

    return db_post

# [게시글 비밀번호 확인 API] - 상세 보기 전 인증 (유지)
@app.post("/api/posts/{post_id}/verify")
async def verify_post_password(
    post_id: int = Path(..., description="게시글 ID"),
    password_data: PasswordCheck = Body(...),
    session: AsyncSession = Depends(get_async_session)
):
    statement = select(models.AnalysisRequest).where(
        models.AnalysisRequest.id == post_id
    )
    result = await session.execute(statement)
    db_post = result.scalars().one_or_none()

    if not db_post:
        raise HTTPException(status_code=404, detail=f"게시글 ID {post_id}를 찾을 수 없습니다.")

    if not security.verify_password(password_data.password, db_post.password_hash):
        raise HTTPException(status_code=401, detail="비밀번호가 일치하지 않습니다.")

    return {"status": "success", "message": "비밀번호가 확인되었습니다."}

# 🚨 수정: [게시글 삭제 API] - 비밀번호 확인 없이 바로 삭제
@app.delete("/api/posts/{post_id}")
async def delete_post(
    post_id: int = Path(..., description="삭제할 게시글 ID"),
    # 🚨 수정: password_data 파라미터 제거 (비밀번호 안 받음)
    session: AsyncSession = Depends(get_async_session)
):
    # 1. DB에서 게시글 조회
    statement = select(models.AnalysisRequest).where(
        models.AnalysisRequest.id == post_id
    )
    result = await session.execute(statement)
    db_post = result.scalars().one_or_none()

    if not db_post:
        raise HTTPException(status_code=404, detail=f"게시글 ID {post_id}를 찾을 수 없습니다.")

    # 2. 비밀번호 검증 로직 제거됨

    # 3. 연결된 파일 삭제 (uploads 폴더에서)
    try:
        # 원본 영상 삭제
        if db_post.original_video_path and os.path.exists(db_post.original_video_path):
            os.remove(db_post.original_video_path)
            print(f"원본 파일 삭제됨: {db_post.original_video_path}")
            
        # 분석된 영상 삭제
        if db_post.analyzed_video_path:
            relative_path = db_post.analyzed_video_path.lstrip('/')
            if not relative_path.startswith(UPLOAD_DIRECTORY):
                 fname = os.path.basename(db_post.analyzed_video_path)
                 real_path = os.path.join(UPLOAD_DIRECTORY, fname)
            else:
                 real_path = relative_path
                 
            if os.path.exists(real_path):
                os.remove(real_path)
                print(f"분석 파일 삭제됨: {real_path}")

    except Exception as e:
        print(f"파일 삭제 중 오류 발생 (DB는 삭제 진행): {e}")

    # 4. DB에서 레코드 삭제
    await session.delete(db_post)
    await session.commit()

    return {"status": "success", "message": "게시글과 관련 파일이 삭제되었습니다."}


# [관리자 분석 시작 API] (YOLOv8 Face 적용됨)
@app.post("/admin/analyze/{post_id}", response_model=PostDetailResponse) 
async def start_analysis(
    post_id: int = Path(..., description="분석할 게시글의 ID"),
    session: AsyncSession = Depends(get_async_session)
):
    statement = select(models.AnalysisRequest).where(
        models.AnalysisRequest.id == post_id
    )
    result = await session.execute(statement)
    db_post = result.scalars().one_or_none()

    if not db_post:
        raise HTTPException(status_code=404, detail=f"게시글 ID {post_id}를 찾을 수 없습니다.")

    if db_post.status == STATUS_COMPLETED:
        raise HTTPException(status_code=400, detail="이미 분석이 완료된 게시글입니다.")
    if db_post.status == STATUS_IN_PROGRESS:
        raise HTTPException(status_code=400, detail="이미 분석이 진행 중입니다.")

    db_post.status = STATUS_IN_PROGRESS
    try:
        session.add(db_post)
        await session.commit()
        await session.refresh(db_post)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB 상태 업데이트 실패: {str(e)}")

    # 3. AI 분석 실행 (YOLOv8 Face 사용)
    try:
        ai_result = await asyncio.to_thread(process_video_for_privacy, db_post.original_video_path)
    except Exception as e:
        print(f"AI 분석 중 치명적인 오류 발생: {e}")
        raise HTTPException(status_code=500, detail=f"AI 분석 중 오류 발생: {str(e)}")

    if "error" in ai_result:
        raise HTTPException(status_code=500, detail=f"AI 모델 오류: {ai_result['error']}")

    db_post.analyzed_video_path = ai_result['analyzed_video_url'] # /uploads/... 경로
    db_post.status = STATUS_COMPLETED 
    
    try:
        session.add(db_post)
        await session.commit()
        await session.refresh(db_post)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB 업데이트 실패: {str(e)}")

    return db_post


# [분석 요청 API] (DB 저장)
@app.post("/request-analysis/", response_model=PostResponse)
async def request_analysis(
    session: AsyncSession = Depends(get_async_session),
    
    title: str = Form(...),
    author: str = Form(...),
    content: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    
    video: UploadFile = File(...)
):
    hashed_password = security.get_password_hash(password)

    base, ext = os.path.splitext(video.filename)
    unique_filename = f"{str(uuid.uuid4())}_{video.filename}" 
    save_path = os.path.join(UPLOAD_DIRECTORY, unique_filename)

    try:
        await asyncio.to_thread(shutil.copyfileobj, video.file, open(save_path, "wb"))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"파일 저장 실패: {str(e)}")
    finally:
        video.file.close()

    current_status = STATUS_PENDING

    new_request = models.AnalysisRequest(
        title=title,
        author=author,
        content=content,
        email=email,
        password_hash=hashed_password,
        original_video_filename=video.filename,
        original_video_path=save_path,
        analyzed_video_path=None, 
        status=current_status     
    )

    try:
        session.add(new_request)
        await session.commit()
        await session.refresh(new_request) 
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB 저장 실패: {str(e)}")

    return new_request